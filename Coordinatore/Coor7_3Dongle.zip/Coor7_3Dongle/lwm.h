// Dummy file that can be included by sketches to let the Arduino IDE
// autodetect the dependency on this library. It will then add the src/
// directory to the include path, so sketches can include the specific
// files they need. For example:
// #include <lwm.h>
// #include <lwm/nwk/nwk.h>
