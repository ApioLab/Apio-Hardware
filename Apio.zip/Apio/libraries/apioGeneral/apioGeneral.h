#include <Arduino.h>

void generalSetup()
{
	Serial.begin(9600);
	Serial.println("general started");
}